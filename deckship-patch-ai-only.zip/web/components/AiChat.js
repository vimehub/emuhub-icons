"use client";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

const AI_AVATAR_STATIC = "https://vimehub.github.io/emuhub-icons/icons/vilyx.jpg";
const AI_AVATAR_ANIM = "https://vimehub.github.io/emuhub-icons/icons/vilyx.gif";
// Avatar: diam (jpg) saat idle, bergerak (gif) saat AI mengetik
const AI_AVATAR = busy ? AI_AVATAR_ANIM : AI_AVATAR_STATIC;

export default function AiChat() {
  const [enabled, setEnabled] = useState(false);
  const [open, setOpen] = useState(false);
  const [me, setMe] = useState(null);
  const [msgs, setMsgs] = useState([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [guestOk, setGuestOk] = useState(false);

  useEffect(() => {
    fetch("/api/ai/config")
      .then((r) => r.json())
      .then((d) => setEnabled(!!d.enabled))
      .catch(() => {});
    try {
      if (localStorage.getItem("emuhub:ai-guest-ok") === "1") setGuestOk(true);
    } catch {}
    fetch("/api/actor")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setMe(d?.actor || null))
      .catch(() => {});
  }, []);

  if (!enabled || typeof document === "undefined") return null;

  const isGuest = !me;
  const showGreet = open && isGuest && !guestOk && msgs.length === 0;

  const toggle = () => setOpen((o) => !o);

  const asGuest = () => {
    setGuestOk(true);
    try {
      localStorage.setItem("emuhub:ai-guest-ok", "1");
    } catch {}
    setMsgs([{ role: "assistant", content: "Halo! Saya vilyx AI. Silakan tanya apa saja 😊" }]);
  };

  const openLogin = (mode) => {
    window.dispatchEvent(new CustomEvent("emuhub:open-login", { detail: { mode } }));
  };

  const send = async () => {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    setMsgs((m) => [...m, { role: "user", content: text }]);
    setBusy(true);
    try {
      const r = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });
      const d = await r.json();
      setMsgs((m) => [...m, { role: "assistant", content: d.reply || "Maaf, tidak ada respons." }]);
    } catch (e) {
      setMsgs((m) => [...m, { role: "assistant", content: "Gagal menghubungi AI." }]);
    } finally {
      setBusy(false);
    }
  };

  return createPortal(
    <>
      <div
        style={{
          position: "fixed",
          bottom: 24,
          right: 24,
          zIndex: 9999,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        {busy && (
          <div
            style={{
              background: "rgba(0,0,0,0.8)",
              borderRadius: 16,
              padding: "8px 16px",
              marginBottom: 8,
              textAlign: "center",
            }}
          >
            <div style={{ color: "#fff", fontWeight: "bold", fontSize: 14 }}>vilyx</div>
            <div style={{ color: "#aaa", fontSize: 12 }}>☰ sedang menanggapi</div>
          </div>
        )}
        <button
          onClick={toggle}
          aria-label="Chat dengan AI"
          style={{
            width: 64,
            height: 64,
            borderRadius: "50%",
            border: "3px solid #3b82f6",
            background: "#fff",
            cursor: "pointer",
            boxShadow: "0 4px 16px rgba(0,0,0,0.25)",
            overflow: "hidden",
            padding: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
        {open ? (
          <span style={{ fontSize: 24 }}>✖</span>
        ) : (
          <img
            src={AI_AVATAR}
            alt="AI"
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
            onError={(e) => {
              e.target.style.display = "none";
              e.target.parentElement.textContent = "🤖";
            }}
          />
        )}
      </button>
      </div>
      {open && (
        <div
          style={{
            position: "fixed",
            bottom: 100,
            right: 24,
            width: 340,
            maxWidth: "calc(100vw - 48px)",
            height: 480,
            maxHeight: "calc(100vh - 140px)",
            background: "#fff",
            border: "1px solid #e5e5e5",
            borderRadius: 16,
            boxShadow: "0 8px 32px rgba(0,0,0,0.2)",
            zIndex: 9998,
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", borderBottom: "1px solid #e5e5e5" }}>
            <img src={AI_AVATAR} alt="AI" style={{ width: 40, height: 40, borderRadius: "50%", objectFit: "cover" }} onError={(e) => (e.target.style.display = "none")} />
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: "bold" }}>vilyx AI</div>
              <div style={{ fontSize: 12, color: "#888" }}>{busy ? "mengetik…" : "online"}</div>
            </div>
            <button onClick={toggle} style={{ border: "none", background: "none", cursor: "pointer", fontSize: 18 }}>✖</button>
          </div>
          <div style={{ flex: 1, overflowY: "auto", padding: 12, display: "flex", flexDirection: "column", gap: 8 }}>
            {msgs.map((m, i) => (
              <div
                key={i}
                style={{
                  maxWidth: "85%",
                  padding: "8px 12px",
                  borderRadius: 12,
                  fontSize: 14,
                  background: m.role === "user" ? "#3b82f6" : "#f0f0f0",
                  color: m.role === "user" ? "#fff" : "#000",
                  alignSelf: m.role === "user" ? "flex-end" : "flex-start",
                }}
              >
                {m.content}
              </div>
            ))}
            {showGreet && (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <button onClick={() => openLogin("login")} style={{ padding: 10, borderRadius: 8, border: "1px solid #e5e5e5", cursor: "pointer" }}>
                  🔑 Masuk
                </button>
                <button onClick={() => openLogin("register")} style={{ padding: 10, borderRadius: 8, border: "1px solid #e5e5e5", cursor: "pointer" }}>
                  📝 Daftar
                </button>
                <button onClick={asGuest} style={{ padding: 10, borderRadius: 8, border: "1px solid #e5e5e5", cursor: "pointer" }}>
                  👤 Lanjut sebagai tamu
                </button>
              </div>
            )}
            {busy && <div style={{ fontSize: 14, color: "#888" }}>mengetik…</div>}
          </div>
          {(!isGuest || guestOk) && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                send();
              }}
              style={{ display: "flex", gap: 8, padding: 12, borderTop: "1px solid #e5e5e5" }}
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Tulis pertanyaan…"
                style={{ flex: 1, padding: "10px 12px", border: "1px solid #e5e5e5", borderRadius: 20, outline: "none" }}
              />
              <button type="submit" disabled={busy || !input.trim()} style={{ padding: "10px 16px", borderRadius: 20, border: "none", background: "#3b82f6", color: "#fff", cursor: "pointer" }}>
                ➤
              </button>
            </form>
          )}
        </div>
      )}
    </>,
    document.body
  );
}
